/*NSRCOPYRIGHT
	Copyright (C) 1999-2008 University of Washington
	Developed by the National Simulation Resource
	Department of Bioengineering,  Box 355061
	University of Washington, Seattle, WA 98195-5061.
	Dr. J. B. Bassingthwaighte, Director
END_NSRCOPYRIGHT*/

/* External calls to C model */

extern int xsimPSize();
extern void xsimSetP(int, double);
extern double xsimGetP(int);
extern void xsimini(), xsimlop(), xsimend();



